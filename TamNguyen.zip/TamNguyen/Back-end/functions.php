<?php
//


namespace twentytwentychild;

add_action('wp_enqueue_scripts', 'twentytwentychild\my_theme_enqueue_styles');
function my_theme_enqueue_styles()
{
    $parenthandle = 'parent-style'; // This is 'twentyfifteen-style' for the Twenty Fifteen theme.
    $theme = wp_get_theme();
    wp_enqueue_style($parenthandle, get_template_directory_uri() . '/style.css',
        array(),  // if the parent theme code has a dependency, copy it to here
        $theme->parent()->get('Version')
    );
    wp_enqueue_style('child-style', get_stylesheet_uri(),
        array($parenthandle),
        $theme->get('Version') // this only works if you have Version in the style header
    );
}

// We don't need this function
// function update_views_cron($rand)
// {
//     for ($i = 0; $i < 10; $i++)
//         \twentytwentychild\update_views();

// }

function update_views()
{
    global $wpdb;
    $views = $wpdb->get_row($wpdb->prepare("SELECT option_value FROM $wpdb->options WHERE option_name = %s LIMIT 1", 'views'));
//    print_r($views);

    if (is_object($views)) {
//        echo "query...UPDATE $wpdb->options/ WHERE option_name='views' SET option_value=" . ($views->option_value + 1);
        $wpdb->query("UPDATE $wpdb->options SET option_value=" . ($views->option_value + 1) . " WHERE option_name='views'");
    } else {
//        update_option('views', 0);
        // $wpdb->query("UPDATE $wpdb->options SET option_value=0 WHERE option_name='views'");

        //insert row 'views' to database 
        $wpdb->query("INSERT INTO `wp_options` (`option_name`, `option_value`, `autoload`) VALUES ('views','0',	'yes')");
    }
}


function get_views()
{
    global $wpdb;
    $views = $wpdb->get_row($wpdb->prepare("SELECT option_value FROM $wpdb->options WHERE option_name = %s LIMIT 1", 'views'));
    $return_view_count = 0;
    if (is_object($views)) {
        $return_view_count = $views->option_value;
    }
    return $return_view_count;
}

function get_views_paragraph()
{
    return sprintf("<p>%s</p>", \twentytwentychild\get_views());
}

//We don't need this function
// add_filter('cron_schedules', '\twentytwentychild\cron_interval');
// function cron_interval($schedules)
// {
//     $schedules['one_second'] = array(
//         'interval' => 1,
//         'display' => esc_html__('Every one second'),);
//     return $schedules;
// }


// Pageviews
add_action('init', function () {
    \twentytwentychild\update_views();
    //We don't need this function
    //wp_schedule_event(time(), 'one_second', 'twentytwentychild\update_views_cron');

});


add_shortcode('views', 'twentytwentychild\get_views_paragraph');