const menuBtn = document.querySelector('.menu-btn');
const menuIcon = document.querySelector('.btn-icon');
const nav = document.querySelector('.nav');
const menuNav = document.querySelector('.menu-nav');

const navItems = document.querySelectorAll('.menu-item');
let showMenu = false;

//add click event for menuBtn
menuBtn.addEventListener('click', toggleMenu);
//handle showMenu
function toggleMenu(){
    // console.log("test");
    if(!showMenu){
        menuIcon.classList.add('open');
        nav.classList.add('open');
        menuNav.classList.add('open');
        navItems.forEach(item => item.classList.add('open'));
        showMenu = true;
    }else{
        menuIcon.classList.remove('open');
        nav.classList.remove('open');
        menuNav.classList.remove('open');
        navItems.forEach(item => item.classList.remove('open'));
        showMenu = false;
    }
}

//close popup handle
function togglePopUp(){
  const popUp = document.querySelector('.pop-up-card');
  popUp.classList.toggle('show');
}
//Immediately invoked function to handle
//only show if the user has visited the website at least once 
(function () {
  if (localStorage.getItem('visted') !== 'true') {
      localStorage.setItem('visted', 'true');
      const popUp = document.querySelector('.pop-up-card');
      popUp.classList.add('show');
  }
})();

//split date and reformat them to MM/DD/YYYY
function getFormattedDate(date) {
  let d = date.split(/[ |,/-]/);
  d = new Date(d[0] + '/' + d[1] + '/' + d[2]);

  let month = (d.getMonth() + 1).toString();
  month = month.length > 1 ? month : '0' + month;

  let day = d.getDate().toString();
  day = day.length > 1 ? day : '0' + day;

  let year = d.getFullYear();
  return month + '/' + day + '/' + year;
}
//reformat all date to MM/DD/YYYY
const dates = document.querySelectorAll('.date');
dates.forEach(item => {
  let date = getFormattedDate(item.textContent);
  item.textContent = date;
});

// set theme
function setTheme(themeName) {
  localStorage.setItem('theme', themeName);
  document.documentElement.className = themeName;
}

// toggle theme: primary/invert theme
function toggleTheme() {
  if (localStorage.getItem('theme') === 'invert-theme') {
    setTheme('primary-theme');
  } else {
    setTheme('invert-theme');
  }
}

// set the theme on initial load
(function () {
  if (localStorage.getItem('theme') === 'invert-theme') {
    setTheme('invert-theme');
  } else {
    setTheme('primary-theme');
  }
})();
